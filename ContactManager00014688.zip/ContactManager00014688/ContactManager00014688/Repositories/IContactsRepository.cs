﻿using ContactManager00014688.Models;

namespace ContactManager00014688.Repositories
{
    public interface IContactsRepository
    {
        Task<IEnumerable<Contact>> GetAllContacts();

        Task <Contact> GetSingleContact(int id);

        Task CreateContact(Contact contact);

        Task UpdateContact (Contact contact);

        Task DeleteContact (int id);
    }
}
