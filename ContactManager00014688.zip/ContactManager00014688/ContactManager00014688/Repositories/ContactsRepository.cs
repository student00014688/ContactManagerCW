﻿using ContactManager00014688.Data;
using ContactManager00014688.Models;
using Microsoft.EntityFrameworkCore;

namespace ContactManager00014688.Repositories
{
    public class ContactsRepository : IContactsRepository
    {
        private readonly ContactManagerDbContext _dbContext;

        public ContactsRepository(ContactManagerDbContext dbContext)
        {
           _dbContext = dbContext;
        }
        public async Task<IEnumerable<Contact>> GetAllContacts()
        {
            var contacts = await _dbContext.Contacts.ToListAsync();
            return contacts;
        }

        public async Task<Contact> GetSingleContact(int id)
        {
            return await _dbContext.Contacts.FirstOrDefaultAsync(c => c.Id == id);
        }
        public async Task CreateContact(Contact contact)
        {
            await _dbContext.Contacts.AddAsync(contact);
            await _dbContext.SaveChangesAsync();
        }

        public async Task DeleteContact(int id)
        {
            var contact = await _dbContext.Contacts.FirstOrDefaultAsync(c => c.Id == id);
            if (contact != null)
            {
                _dbContext.Contacts.Remove(contact);
                await _dbContext.SaveChangesAsync();
            }
        }

        

        public async Task UpdateContact(Contact contact)
        {
            _dbContext.Entry(contact).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
        }
    }
}
