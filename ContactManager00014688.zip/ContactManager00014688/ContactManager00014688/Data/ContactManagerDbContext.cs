﻿using ContactManager00014688.Models;
using Microsoft.EntityFrameworkCore;

namespace ContactManager00014688.Data
{
    public class ContactManagerDbContext : DbContext
    {
        public ContactManagerDbContext(DbContextOptions<ContactManagerDbContext> options) : base(options) { }
        public DbSet<Contact> Contacts { get; set; }

        public DbSet<Category> Categories { get; set; }


    }
}
